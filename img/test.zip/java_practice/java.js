let button = document.getElementById('mybutton');
button.addEventListener('click', butotnClick1);
button.addEventListener('click', butotnClick2);